
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mysql = require('mysql2');
const path = require('path');

const app = express();
app.use(bodyParser.json());
app.use(cors());

// Set up MySQL connection
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '1234',
    port: 3306,
    database: 'feedtocare',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});



app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'Signup.html'));
});
