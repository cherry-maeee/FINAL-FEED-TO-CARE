// Import the express module
const express = require('express');
const mysql = require('mysql2');
const path = require('path');

// Create an Express application
const app = express();

// Set the views directory and view engine
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs'); // Using EJS as the template engine

// Create a MySQL connection pool
const pool = mysql.createPool({
    host: 'localhost',
 //   port: '3307',
    user: 'root', // Replace with your MySQL username
    password: '1234', // Replace with your MySQL password
    database: 'feedtocare',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// Check if the connection is successful
pool.getConnection((err, connection) => {
    if (err) {
        console.error('Database connection failed: ', err.stack);
        return;
    }

    console.log('Connected to the database.');
});

// Define a route for the profile page
app.get('/profile', (req, res) => {
    // Fetch data from the database
    pool.query('SELECT * FROM profile_data', (err, results) => {
        if (err) {
            console.error('Error fetching data from database: ', err);
            return;
        }
        
        // Render the profile.ejs page with the fetched data
        res.render('profile', { profileData: results });
    });
});

// Start the server
const PORT = process.env.PORT || 5500;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
