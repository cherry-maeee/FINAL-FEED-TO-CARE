async function test() {
    const res = await fetch('http://localhost:5500')

    const res_= await res.json()

    console.log(res_)
}

test()